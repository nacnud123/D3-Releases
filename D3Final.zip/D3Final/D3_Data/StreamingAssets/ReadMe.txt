Freesounds: https://freesound.org/
Spookymodem: https://freesound.org/people/spookymodem/
RedRoxPeterPepper: https://freesound.org/people/RedRoxPeterPepper/
"Chewing, Breadstick, Single, C.wav" by InspectorJ (www.jshaw.co.uk) of Freesound.org
Q.K: https://freesound.org/people/Q.K./
qubodup: https://freesound.org/people/qubodup/
Kinoton: https://freesound.org/people/Kinoton/
Sclolex: https://freesound.org/people/Sclolex/
VR with Andrew: https://www.youtube.com/channel/UCG8bDPqp3jykCGbx-CiL7VQ
Procedual Dungeon Toolkit: https://assetstore.unity.com/packages/templates/systems/procedural-dungeon-toolkit-71317
SteamVR Plugin: https://assetstore.unity.com/packages/tools/integration/steamvr-plugin-32647
Behavior Bricks: https://assetstore.unity.com/packages/tools/visual-scripting/behavior-bricks-74816